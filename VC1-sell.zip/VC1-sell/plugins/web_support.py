from aiohttp import web
import pyrogram.utils

pyrogram.utils.MIN_CHANNEL_ID = -1002185040924

routes = web.RouteTableDef()

@routes.get("/", allow_head=True)
async def root_route_handler(request):
    return web.json_response("SnowEncoderBot")


async def web_server():
    web_app = web.Application(client_max_size=30000000)
    web_app.add_routes(routes)
    return web_app