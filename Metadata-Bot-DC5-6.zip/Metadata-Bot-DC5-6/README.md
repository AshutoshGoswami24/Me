<h2 align="center">
  ─「 ​🇲​​🇪​​🇹​​🇦​​🇩​​🇦​​🇹​​🇦​ ʙᴏᴛ 」─
</h2>

<p>

![Typing SVG](https://readme-typing-svg.herokuapp.com/?lines=ᴡᴇʟᴄᴏᴍᴇ+ᴛᴏ+𝟺ɢʙ+​🇲​​🇪​​🇹​​🇦​​🇩​​🇦​​🇹​​🇦​+​🇧​​🇴​​🇹​!)</p>

<details>
<summary><h3>
- <b> ᴅᴇᴘʟᴏʏᴍᴇɴᴛ ᴍᴇᴛʜᴏᴅs </b>
</h3></summary>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>

<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/Tamilupdates/Metadata-Bot">

  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy On Heroku">
</a></p>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ᴋᴏʏᴇʙ 」─
</h3>
<p align="center"><a href="https://app.koyeb.com/deploy?type=git&repository=github.com/https://github.com/Tamilupdates/Metadata-Bot&branch=main&name=MetadataBot">
  <img src="https://www.koyeb.com/static/images/deploy/button.svg" alt="Deploy On Koyeb">
</a></p>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʀᴀɪʟᴡᴀʏ 」─
</h3>
<p align="center"><a href="https://railway.app/deploy?template=https://github.com/Tamilupdates/Metadata-Bot"">
     <img height="45px" src="https://railway.app/button.svg">
</a></p>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʀᴇɴᴅᴇʀ 」─
</h3>
<p align="center"><a href="https://render.com/deploy?repo=https://github.com/Tamilupdates/Metadata-Bot">
<img src="https://render.com/images/deploy-to-render-button.svg" alt="Deploy to Render">
</a></p>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ᴠᴘs 」─
</h3>
<p>
<pre>
git clone https://github.com/Tamilupdates/Metadata-Bot
# Install Packages
pip3 install -U -r requirements.txt
Edit info.py with variables as given below then run bot
python3 bot.py
</pre>
</p>
</details>



## - ᴇɴᴠɪʀᴏɴᴍᴇɴᴛ ᴠᴀʀɪᴀʙʟᴇs
  - `API_ID` - Your Telegram API ID.
  - `API_HASH` - Your Telegram API HASH.
  - `TOKEN` - Get it from BotFather.
  - `ADMIN` - Your ID
  - `DB_URL` - Enter Mongodb database URL
  - `DB_NAME` - Enter Mongodb database URL Name
  - `FORCE_SUB` - Force subscribe channel username without `@`
  - `LOG_CHANNEL` - Log Channel ID.
  - `START_PIC` - Start Message Photo. You Don't Need This! Just Skip
  - `WEBHOOK` -  If Your Server Is Need Web Service! Value = True Else Value = False
  - `STRING_API_ID` - Your Premium Account API ID
  - `STRING_API_HASH` - Your Premium Account API HASH
  - `STRING_SESSION` - Your Premium Account SESSION STRING (OPTIONAL VARIABLE)

## Botfather Commands
```
start - Bot Alive Cheking
view_thumb - View Thumbnail
del_thumb - Delete Thumbnail
set_caption - Set A Custom Caption
see_caption - See Your Custom Caption
del_caption - Delete Custom Caption
metadata - To Set & Change your metadata code
set_prefix - To Set Your Prefix
set_suffix - To Set Your Suffix
see_prefix - To See Your Prefix
see_suffix - To See Your Suffix
del_prefix - Delete Your Prefix
del_suffix - Delete Your Suffix
restart - To Rrstart The Bot (Admin Only)
status - Check Bot Status (Admin Only)
broadcast - Send Message To All Users (Admin Only)
```

<h3>「 ɴᴏᴛᴇ 」
</h3>

 - <b>ɪᴍᴘᴏʀᴛɪɴɢ ᴛʜɪs ʀᴇᴘᴏ ɪɴsᴛᴇᴀᴅ ᴏғ ғᴏʀᴋɪɴɢ ɪs sᴛʀɪᴄᴛʟʏ ᴘʀᴏʜɪʙɪᴛᴇᴅ 🚫 ᴋɪɴᴅʟʏ ғᴏʀᴋ ᴀɴᴅ ᴇᴅɪᴛ ᴀs ʏᴏᴜʀ ᴡɪsʜ (ᴍᴜsᴛ ɢɪᴠᴇ ᴄʀᴇᴅɪᴛs ғᴏʀ ᴅᴇᴠs) 🙃</b>
 - <b>ɪғ ʏᴏᴜ ғɪɴᴅ ᴀɴʏ ʙᴜɢs ᴏʀ ᴇʀʀᴏʀs, ʀᴇᴘᴏʀᴛ ɪᴛ ᴛᴏ ᴛʜᴇ ᴅᴇᴠᴇʟᴏᴘᴇʀ.</b>
